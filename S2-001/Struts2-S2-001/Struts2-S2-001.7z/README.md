启动容器，访问/Struts2-S2-001_war

正常登陆，用户名为admin 密码为admin